/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package chatprogramm;

/**
 *
 * @author Nico
 */
public class main {
    public static void main(String[] args) {
        
    }
}
